# Resume Enhancer App

## Description
A simple full-stack application to edit and enhance resumes using mocked AI features.

## Tech Stack
- Frontend: React.js
- Backend: FastAPI

## Setup Instructions

### Frontend
```bash
cd frontend
npm install
npm start
```

### Backend
```bash
cd backend
pip install fastapi uvicorn
uvicorn main:app --reload
```

## API Endpoints

### POST /ai-enhance
Enhances a resume section (mocked response).

### POST /save-resume
Saves full resume JSON to disk.
