from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json

app = FastAPI()

# CORS config to allow frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class EnhanceRequest(BaseModel):
    section: str
    content: str

class SaveResumeRequest(BaseModel):
    resume: dict

@app.post("/ai-enhance")
async def enhance_section(req: EnhanceRequest):
    # Mock AI-enhanced response
    improved = f"[Enhanced] {req.content}"
    return {"enhanced_content": improved}

@app.post("/save-resume")
async def save_resume(req: SaveResumeRequest):
    with open("resume.json", "w") as f:
        json.dump(req.resume, f, indent=4)
    return {"status": "Resume saved successfully"}
